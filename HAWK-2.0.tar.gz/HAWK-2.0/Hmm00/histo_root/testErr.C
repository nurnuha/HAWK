auto c=new TCanvas();c->SetGrid();
TGraphErrors graph_expected("./test_TError03.txt","%lg %lg %lg");
graph_expected.SetTitle("Measurement XYZ and Expectation;lenght [cm];Arb.Units");
graph_expected.SetFillColor(kYellow);
graph_expected.DrawClone("E3AL"); // E3 draws the band

TGraphErrors graph("./test_TError04.txt","%lg %lg %lg");
graph.SetMarkerStyle(2);
graph.SetFillColor(0);
graph.DrawClone("PESame");
