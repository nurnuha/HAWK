void
tree_xsec03()
{
  TTree* t = new TTree("T", "X-sections");
  TTree* f = new TTree("F", "X-section");
  t->ReadFile("complete03.xsec",
              "massZH/D:"
      	      "aXsec:eXsec");
  f->ReadFile("complete04.xsec", 
              "massZH/D:"
      	      "aXsec:eXsec");
  t->SetMarkerColor(4); //4 is blu: with EW correction
  t->SetMarkerStyle(2);
  f->SetMarkerColor(2); //2 is red:without EW correction
  f->SetMarkerStyle(2);
  t->Draw("aXsec:massZH", "", "*");
  f->Draw("aXsec:massZH", "", "* same");
}
