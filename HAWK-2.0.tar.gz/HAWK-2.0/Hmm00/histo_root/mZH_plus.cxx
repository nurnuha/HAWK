{
// File to use (root/histogram/etc)
TFile f1("Born03.root");
TCanvas *c1 = f1.Get("c1");

// Declare the variables

 TFile f2("Born04.root");
 TCanvas *c2 = f2.Get("c1");

// Update the index for second tree

// TCanvas *c01 = new TCanvas("c1", "c1", 100, 100, 1600, 900);
// gStyle->SetOptStat(0);
// c1->Draw();
// c2->Draw("same");

 TLegend* leg = new TLegend(0.77, 0.77, .93, .93);
   leg->AddEntry(histo1, "ptPi of MC");
   leg->AddEntry(histo2, "ptPi of data");
   leg->SetTextSize(0.04);
   leg->SetFillColor(0);
   leg->Draw();

   return c01;

}
