//cubaan utk memplot hanya da first column

{
  gROOT->Reset();
  // open a file, just like on c
  FILE *fp = fopen("/home/nuha/Documents/HAWK-2.0/test/root_method/dat.pth","r");
  //Declare some variables
Float_t c1;
 Int_t ncols,nlines=0;
 TFile *f = new TFile("lala.root", "RECREATE");
 TNtuple *ntuple = new TNtuple("ntuple","data from ascii file","c1");

 while (1)
   {
     ncols = fscanf(fp,"%f",&c1);
     if (ncols < 0) break;
     if (nlines < 5) printf("c1=%g\n",c1);
     ntuple->Fill(c1);
     ++nlines;
}
 printf("found %d points\n",nlines);
 fclose(fp);
 f->Write();
}
