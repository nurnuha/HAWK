//test using example from lecture summer school
#include "Riostream.h"

void test03a()
{

  //TString dir = gSystem->UnixPathName(__FILE__);
  //dir.ReplaceAll("test03a.cxx","");
  //dir.ReplaceAll("/./","/");
ifstream in;
in.open(Form("dat.pth"));

Float_t c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13;
Int_t nlines = 0;
TFile *f = new TFile("pth03a.root", "RECREATE");
TH1F *h1 = new TH1F("h1", "x distribution", 100, -4., 4.);
TNtuple *ntuple = new TNtuple("ntuple", "data from ascii file", "c1:c2:c3:c4:c5:c6:c7:c8:c9:c10:c11:c12:c13");

 while(1) {
  in >> c1 >> c2 >> c3 >> c4 >> c5 >> c6 >> c7 >> c8 >> c9 >> c10 >> c11 >> c12 >> c13;
  if (!in.good()) break;
  if (nlines < 5) printf("c1=%8f, c2=%8f, c3=%8f, c4=%8f, c5=%8f, c6=%8f, c7=%8f, c8=%8f, c9=%8f, c10=%8f, c11=%8f, c12=%8f, c13=%8f\n",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
  h1->Fill(c1);
  ntuple->Fill(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
  nlines++;
   }

   printf("found %d points\n",nlines);

   in.close();

   //printf("found %lld pointsn \n", nlines);
  //t->ReadFile("/home/nuha/Documents/HAWK-2.0/test/dat.pth");
 //  t->Draw("c1");
   //h1->Fill(c1);
 f->Write();
}
