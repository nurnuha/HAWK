#include "Riostream.h"
void basic() {
//  Read data from an ascii file and create a root file with an histogram and an ntuple.
//   see a variant of this macro in basic2.C
//Author: Rene Brun
      

// read file $ROOTSYS/tutorials/tree/basic.dat
// this file has 13 columns of float data
   TString dir = gSystem->UnixPathName(gInterpreter->GetCurrentMacroName());
   dir.ReplaceAll("basic.C","");
   dir.ReplaceAll("/./","/");
   ifstream in;
   in.open(Form("%sdat.pth",dir.Data()));

   Float_t c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13;
   Int_t nlines = 0;
   TFile *f = new TFile("ops.root","RECREATE");
   TH1F *h1 = new TH1F("h1","x distribution",100, 0., 500.);
   TNtuple *ntuple = new TNtuple("ntuple","data from ascii file","c1:c2:c3:c4:c5:c6:c7:c8:c9:c10:c11:c12:c13");

   while (1) {
     in >> c1 >> c2 >> c3 >> c4 >> c5 >> c6 >> c7 >> c8 >> c9 >> c10 >> c11 >> c12 >> c13;
      if (!in.good()) break;
      if (nlines < 5) printf("c1=%8f, c2=%8f, c3=%8f, c4=%8f, c5=%8f, c6=%8f, c7=%8f, c8=%8f, c9=%8f, c10=%8f, c11=%8f, c12=%8f, c13=%8f\n",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
      h1->Fill(c1);
      ntuple->Fill(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
      nlines++;
   }
   printf(" found %d points\n",nlines);

   in.close();

   f->Write();
}
