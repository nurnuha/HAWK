// Next test how to combine all 13 column into 1 graph
//#include "Riostream.h"
int test05(){

  gROOT->SetStyle("Plain");
  TCanvas *c = new TCanvas();
  c.SetGrid();

  TGraphErrors graph_expected("./Documents/HAWK-2.0/test/dat.pth", "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg");
  graph_expected.SetFillColor(kYellow);
  graph_expected.DrawClone("E3AL");

  /*  TGraphErrors graph("./Documents/HAWK-2.0/test/dat.etah", "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg");
  graph.SetMarkerStyle(kCircle);
  graph.SetFillColor(0);
  graph.DrawClone("PESame");
  */
  //Draw the Legend
  TLegend leg(.1,.7,.3,.9, "Lab Lesson 2");
  leg.SetFillColor(0);
  leg.AddEntry(&graph_expected, "Expected Points");
  // leg.AddEntry(&graph, "Measured Points");
  leg.DrawClone("Same");

  c.Print("graph_with_band.pdf");

}
