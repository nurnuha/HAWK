void test02() {
//   example of macro to create can ntuple reading data from an ascii file.
//   This macro is a variant of basic.C
//Author: Rene Brun   

   TString dir = gSystem->UnixPathName(gInterpreter->GetCurrentMacroName());
   dir.ReplaceAll("test02.cxx","");
   dir.ReplaceAll("/./","/");
   
   TFile *f = new TFile("test_pth.root","RECREATE");
   TH1F *h1 = new TH1F("h1","x distribution",100,0,500);
   TTree *T = new TTree("ntuple","data from ascii file");
   Long64_t nlines = T->ReadFile(Form("%pth.dat",dir.Data()),"x:y:z");
   printf(" found %lld points\n",nlines);
   T->Draw("x","z>2");
   T->Write();
}
