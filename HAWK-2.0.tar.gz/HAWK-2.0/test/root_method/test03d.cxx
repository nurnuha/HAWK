//test to plot only 1 column

void test03d()
{

  //TString dir = gSystem->UnixPathName(__FILE__);
  //dir.ReplaceAll("test03a.cxx","");
  //dir.ReplaceAll("/./","/");
ifstream in;
in.open(Form("/home/nuha/Documents/HAWK-2.0/test/root_method/dat.pth"));

Float_t c1;
Int_t nlines = 0;
TFile *f = new TFile("pth03d.root", "RECREATE");
TH1F *h1 = new TH1F("h1", "x distribution", 100, 0, 400.);
TNtuple *ntuple = new TNtuple("ntuple", "data from ascii file", "c1");

 while(1) {
  in >> c1;
  if (!in.good()) break;
  if (nlines < 5) printf("c1=%8f\n",c1);
  h1->Fill(c1);
  ntuple->Fill(c1);
  nlines++;
   }

   printf("found %d points\n",nlines);

   in.close();

   //printf("found %lld pointsn \n", nlines);
  //t->ReadFile("/home/nuha/Documents/HAWK-2.0/test/dat.pth");
 //  t->Draw("c1");
   //h1->Fill(c1);
 f->Write();
}
