void test06(){

    TCanvas* c=new TCanvas();
    c->SetGrid();
    /*
    TGraphErrors graph_expected("./Documents/HAWK-2.0/test/dat.etah", "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg");
    graph_expected.SetTitle("Measurement XYZ and Expectation;lenght [cm];Arb.Units");
    graph_expected.SetFillColor(kYellow);
    graph_expected.DrawClone("E3AL"); // E3 draws the band
    */
    TGraphErrors graph("./home/nuha/Documents/HAWK-2.0/test/dat.pth","%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg %lg");
    graph.SetMarkerStyle(kCircle);
    graph.SetFillColor(0);
    graph.Draw();
    
    // Draw the Legend
    TLegend leg(.1,.7,.3,.9,"Lab. Lesson 2");
    leg.SetFillColor(0);
    // leg.AddEntry(&graph_expected,"Expected Points");
    leg.AddEntry(&graph,"Measured Points");
    leg.Draw();

    graph.Print();
}
