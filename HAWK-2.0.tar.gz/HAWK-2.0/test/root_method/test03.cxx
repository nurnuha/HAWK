#include "TFile.h"
#include "TH1.h"
#include "TH2.h"
#include "TProfile.h"
#include "TRandom.h"
#include "TTree.h"
#include "Riostream.h"

void test03()
{
gROOT->Reset();
Float_t c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13;
TFile *f = new TFile("pth03.root", "RECREATE");
TH1F *h1 = new TH1F("h1", "x distribution", 100, 0., 500.);
TTree *t = new TTree("t","pth");

 t->Branch("c1", &c1, "c1/F");
 t->Branch("c2", &c2, "c2/F");
 t->Branch("c3", &c3, "c3/F");
 t->Branch("c4", &c4, "c4/F");
 t->Branch("c5", &c5, "c5/F");
 t->Branch("c6", &c6, "c6/F");
 t->Branch("c7", &c7, "c7/F");
 t->Branch("c8", &c8, "c8/F");
 t->Branch("c9", &c9, "c9/F");
 t->Branch("c10", &c10, "c10/F");
 t->Branch("c11", &c11, "c11/F");
 t->Branch("c12", &c12, "c12/F");
 t->Branch("c13", &c13, "c13/F");

Long64_t nlines = t->ReadFile("/home/nuha/Documents/HAWK-2.0/test/dat.pth", "c1:c2:c3:c4:c5:c6:c7:c8:c9:c10:c11:c12:c13");
/*
   while (1) {
     t >> c1 >> c2 >> c3 >> c4 >> c5 >> c6 >> c7 >> c8 >> c9 >> c10 >> c11 >> c12 >> c13;
      if (!in.good()) break;
      if (nlines < 5) printf("c1=%8f, c2=%8f, c3=%8f, c4=%8f, c5=%8f, c6=%8f, c7=%8f, c8=%8f, c9=%8f, c10=%8f, c11=%8f, c12=%8f, c13=%8f \n",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
      h1->Fill(c1);
      // ntuple->Fill(x,y,z);
      nlines++;
   }
*/
   printf(" found %d points\n",nlines);

   //   t.close();

   //printf("found %lld pointsn \n", nlines);
  //t->ReadFile("/home/nuha/Documents/HAWK-2.0/test/dat.pth");
 //  t->Draw("c1");
   //h1->Fill(c1);
 t->Write();
}
