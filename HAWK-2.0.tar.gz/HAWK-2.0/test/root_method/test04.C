#include "Riostream.h"
void test04() {
//  Read data from an ascii file and create a root file with an histogram and an ntuple.
//   see a variant of this macro in basic2.C
//Author: Rene Brun
      

// read file $ROOTSYS/tutorials/tree/basic.dat
// this file has 3 columns of float data
   TString dir = gSystem->UnixPathName(gInterpreter->GetCurrentMacroName());
   dir.ReplaceAll("test04.C","");
   dir.ReplaceAll("/./","/");
   ifstream in;
   in.open(Form("%spth.dat",dir.Data()));

   Float_t c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13;
   Int_t nlines = 0;
   TFile *f = new TFile("pth02.root","RECREATE");
   TH1F *h1 = new TH1F("h1","x distribution",100,-4,4);
   TNtuple *ntuple = new TNtuple("ntuple","data from ascii file","c1:c2:c3:c4:c5:c6:c7:c8:c9:c10:c11:c12:c13");

   while (1) {
      in  >> c1 >> c2 >> c3 >> c4 >> c5 >> c6 >> c7 >> c8 >> c9 >> c10 >> c11 >> c12 >> c13;
      if (!in.good()) break;
      if (nlines < 5) printf("c1=%8f, c2=%8f, c3=%8f\n",c1,c2,c3);
      h1->Fill(c1);
      ntuple->Fill(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13);
      nlines++;
   }
   printf(" found %d points\n",nlines);

   in.close();

   f->Write();
}
