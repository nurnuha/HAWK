//test using example from cheatcode

{
  gROOT->Reset();
  // open a file, just like on c
  FILE *fp = fopen("/home/nuha/Documents/HAWK-2.0/test/dat.pth","r");
  //Declare some variables
Float_t c1,c2,c3,c4,c5,c6,c7,c8,c9,c10;
 Int_t ncols,nlines=0;
 TFile *f = new TFile("lalala.root", "RECREATE");
 TNtuple *ntuple = new TNtuple("ntuple","data from ascii file","c1:c2:c3:c4:c5:c6:c7:c8:c9:c10");

 while (1)
   {
     ncols = fscanf(fp,"%f %f %f %f %f %f %f %f %f %f",&c1, &c2, &c3, &c4, &c5, &c6, &c7, &c8, &c9, &c10);
     if (ncols < 0) break;
     if (nlines < 5) printf("c1=%g, c2=%g, c3=%g, c4=%g, c5=%g, c6=%g, c7=%g, c8=%g, c9=%g, c10=%g\n",c1,c2,c3,c4,c5,c6,c7,c8,c9,c10);
     ntuple->Fill(c1,c2,c3,c4,c5,c6,c7,c8,c9,c10);
     ++nlines;
}
 printf("found %d points\n",nlines);
 fclose(fp);
 f->Write();
}
