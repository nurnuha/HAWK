void
test_tree()
{
  TTree* t = new TTree("T", "X-sections");
  //  TFile f1("mzh01.root","RECREATE");
  t->ReadFile("dat.mZH","massZH_WoE:""aBornxsec:");
  //  t->ReadFile("dat.mZH","kine/D:""aBorn:eBorn:");

	      // "aComplete:eComplete:"
      	      //"aEW:eEW:"
	      //"aQCD:eQCD:"
	      //"aGamma:eGamma:"
	      //"aGluon:eGluon");
  //   t->Fill("aBorn:kine");
  //   t->Write();
     t->Print();
     t->Draw("aBornxsec:massZH_WoE", "", "*");
     //     t->Draw("aBorn:kine", "", "* same");

	      // t->Draw("aComplete:kine", "", "* same");
	      //  t->Draw("aEW:kine", "", "* same");
	      // t->Draw("aQCD:kine", "", "* same");
	      // t->Draw("aGamma:kine", "", "* same");
	      // t->Draw("aGluon:kine", "", "* same");
}
