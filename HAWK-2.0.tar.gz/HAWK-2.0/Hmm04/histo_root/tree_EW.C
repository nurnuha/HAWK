void
tree_EW()
{
  TTree* t = new TTree("T", "X-sections");
  t->ReadFile("EW.xsec",
              "massZH/D:"
      	      "aEW:eEW");

  t->Print();
  t->Draw("aEW:massZH", "", "*");
}
