void
tree_xsec04()
{
  TTree* t = new TTree("T", "X-sections");
  t->ReadFile("complete04.xsec",
              "massZH/D:"
     	      "aComplete:eComplete");


  t->Print();
  t->Draw("aComplete:massZH", "", "*");
 
}
