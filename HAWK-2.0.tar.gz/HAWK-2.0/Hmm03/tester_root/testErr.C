//Reads the points from file, get the point x,y and calculate relative diff.

void testErr(){
auto c=new TCanvas();

//Read file one    
    TGraphErrors graph03("./complete03.xsec","%lg %lg %lg");

//Read file two
//  TGraphErrors graph04("./complete04.xsec","%lg %lg %lg");


//    TGraphErrors *gr1 = new TGraphErrors();
//Calculate rel.err & Create new graph
    Double_t point1, point2, diff, relerr, point3;
    // int bi = 101;
    for (Int_t i=0; i<=102; i++){
      TGraph::GetPoint(Int_t i, Double_t &point1, Double_t &point2)
	graph03.GetPoint(1, point1, point2);

      printf("x[%d] = %g\n",i,point2);

    /*
      point1 = graph03.GetY(i);
      point2 = graph04.GetY(i);
      diff = point1 - point2;
      relerr = (diff/point1);
      point3 = graph03.GetX();
      gr1->Draw("relerr:point3");*/
}
    //TGraphError *gr = new TGraphError();
    // gr->Draw(relative_error:X1);

    // Draw the Legend
    //    TLegend leg(.1,.7,.3,.9,"Graph");
    //    leg.SetFillColor(0);
    //    leg.AddEntry(&graph03,"Expected Points");
    //    leg.AddEntry(&graph04,"Measured Points");
    //    leg.DrawClone("PESame");

    //  graph.Print();
    

}

//TCanvas *myCanvas = new TCanvas()

//MyTree->Draw("Cost:Age")
