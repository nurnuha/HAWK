void
ReadToNtuple()
{

  std::ifstream in("born.xsec");
  TNtuple* t = new TNtuple("nt", "X-sections",
			   "massZH:"
			   "aBorn:eBorn");

  Long64_t n = t->ReadStream(in);
  Info("ReadToNTuple", "Read %lld entries", n);
  for (Int_t i = 0; i < n; i++) {
    t->GetEntry(i);
    for (Int_t j = 0; j < t->GetNvar(); j++)
      printf("%7.4f ", t->GetArgs()[j]);
    Printf("");
  }
  
  t->Draw("aBorn:massZH", "", "*");
  //  t->Draw("aComplete:kine", "", "* same");
}

