// Reads the points from a file and produces a simple graph.
int testErr(){
    auto c=new TCanvas();c->SetGrid();
    
    TGraphErrors graph_expected("./test_TError03.txt",
                                "%lg %lg %lg");
    graph_expected.SetTitle(
       "Measurement XYZ and Expectation;"
       "lenght [cm];"
       "Arb.Units");
    graph_expected.SetFillColor(kRed);
    graph_expected.DrawClone("E3AL"); // E3 draws the band

    TGraphErrors graph("./test_TError04.txt","%lg %lg %lg");
    graph.SetMarkerStyle(2);
    graph.SetFillColor(kBlue);
    graph.DrawClone("PESame");

    // Draw the Legend
    TLegend leg(.1,.7,.3,.9,"Lab. Lesson 2");
    leg.SetFillColor(0);
    leg.AddEntry(&graph_expected,"Expected Points");
    leg.AddEntry(&graph,"Measured Points");
    leg.DrawClone("Same");

    graph.Print();
    return 0;
    /*
for (int k=1 ; k<3 ; k++) {
   for (int i=1 ; i<100; i++) { 
      Content1 = h1[k]->GetBinContent(i);
      Content2 = h2[k]->GetBinContent(i);

      diff = Content1-Content2 ;
      Double relative_error = (diff/Content1)*100;

   }
    */



}
/*    Double_t point1, point2, point3, point4;
    // int bi = 101;
    for (Int_t i=0; i<=100; i++){
      graph03.GetPoint(i, point1, point2);
      graph04.GetPoint(i, point3, point4);
      printf("x[%d] = %g\n \n  x[%d] = %g\n",i,point2,i,point4);

*/
//TCanvas *c1 = new TCanvas("c1","Testing",200,10,700,500);
//c1->SetFillColor(42);
