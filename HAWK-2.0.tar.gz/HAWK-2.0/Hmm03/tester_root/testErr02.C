//First attempt to use Multigraph

void testErr02(){
   TCanvas *c1 = new TCanvas("c1","multigraph",700,500);
   c1->SetGrid();

   TMultiGraph *mg = new TMultiGraph();

//Create first graph   
    TGraphErrors graph03("./complete03.xsec","%lg %lg %lg");
    //   graph03.SetTitle("Cross section vs Mass ZH;""mass[GeV];""Xsection");
    graph03.SetMarkerColor(kBlue);
    graph03.SetMarkerStyle(21);
    mg->Add(graph03);

//Create second graph
    TGraphErrors graph04("./complete04.xsec","%lg %lg %lg");
    graph04.SetMarkerColor(kRed);
    graph04.SetMarkerStyle(20);
    mg->Add(graph04);

    mg->Draw("apl");
    mg->GetXaxis()->SetTitle("mass ZH");
    mg->GetYaxis()->SetTitle("cross section");

   gPad->Update();
   gPad->Modified();

    // Draw the Legend
    /*    TLegend leg(.1,.7,.3,.9,"Graph");
    leg.SetFillColor(0);
    leg.AddEntry(&graph03,"Expected Points");
    leg.AddEntry(&graph04,"Measured Points");
    leg.DrawClone("PESame");
    */
    // graph.Print();
    
    //return 0;
}
