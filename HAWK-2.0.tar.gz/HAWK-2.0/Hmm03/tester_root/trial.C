//test with one graph only

void trial(){
auto c=new TCanvas();

//Read file one    
    TGraphErrors graph03("./complete03.xsec","%lg %lg %lg");

    TGraphErrors *gr1 = new TGraphErrors();
//Calculate rel.err & Create new graph
    Double_t point1, point2, diff, relerr, point3;
    // int bi = 101;
    for (Int_t i=0; i<=102; i++){

      Double_t aa = graph03.GetPoint(i,point1,point2);

      printf("x[%d] = %g\n",i,point1);

    }}
