{

// File to use (root/histogram/etc)
TFile f1("/home/nuha/bothlc/lQ2.root");
TTree *t1 = (TTree*)f1.Get("lambda");

// Declare the variables

 TH1F *histo1 = new TH1F("histo1", "pt_Pi", 100, 0., 10.);

 Int_t Ngoodcand_1;
 t1->SetBranchAddress("Ngoodcand", &Ngoodcand_1);
 Float_t ptPi1_1[1000];
 t1->SetBranchAddress("ptPi", ptPi1_1);

 Int_t nevent1 = t1->GetEntries();
 for (Int_t aa = 0; aa < nevent1; aa++) {

   t1->GetEntry(aa);

   for (Int_t a = 0; a < Ngoodcand_1; a++)
     histo1->Fill(ptPi1_1[a]);
     histo1->SetFillColor(kRed + 1);
     histo1->SetLineColor(kRed + 1);
     histo1->SetFillStyle(3157);
   
 }

 histo1->Scale(1 / histo1->Integral());

 TFile f2("/home/nuha/bothlc/data.root");
 TTree *t2 = (TTree*)f2.Get("lambda");

// Update the index for second tree
 TH1F *histo2 = new TH1F("histo2", "pt_Pi", 100, 0., 10.);

 Int_t Ngoodcand_2;
 t2->SetBranchAddress("Ngoodcand", &Ngoodcand_2);
 Float_t ptPi1_2[1000];
 t2->SetBranchAddress("ptPi", ptPi1_2);

 Int_t nevent2 = t2->GetEntries();
 for (Int_t bb = 0; bb < nevent2; bb++) {

   t2->GetEntry(bb);

   for (Int_t b = 0; b < Ngoodcand_2; b++)
     histo2->Fill(ptPi1_2[b]);
     histo2->SetFillColor(kAzure + 1);
     histo2->SetLineColor(kAzure + 1);
   
 }

 histo2->Scale(1 / histo2->Integral());

 TCanvas *c01 = new TCanvas("c1", "c1", 100, 100, 1600, 900);
 gStyle->SetOptStat(0);
 histo2->Draw();
 histo1->Draw("same");

 TLegend* leg = new TLegend(0.77, 0.77, .93, .93);
   leg->AddEntry(histo1, "ptPi of MC");
   leg->AddEntry(histo2, "ptPi of data");
   leg->SetTextSize(0.04);
   leg->SetFillColor(0);
   leg->Draw();

   return c01;

}
