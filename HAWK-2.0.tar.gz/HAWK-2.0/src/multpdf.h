      integer pdfmemberfrom,pdfmemberto,pdfmembercentral
      integer maxpdf,aref,iref,iref1
      parameter(maxpdf = 100) 
      double precision alphasratio(maxpdf),keep(100)
      double precision mpdf1(maxpdf,-6:6),mpdf2(maxpdf,-6:6)
      double precision mpdf_phot1(maxpdf),mpdf_phot2(maxpdf)
      real*8 mm2pdfpdf_0(maxpdf*maxps)
      real*8 mm2pdfpdfii_0(maxpdf*maxps,-5:5,-5:5)
      real*8 mm2pdfpdf_vw(maxpdf*maxps)
      real*8 mm2pdfpdfii_vw(maxpdf*maxps,-4:4,-4:4)
      real*8 mm2pdfpdf_vs(maxpdf*maxps)
      real*8 mm2pdfpdfii_vs(maxpdf*maxps,-4:4,-4:4)
      real*8 mm2pdfpdfqq_0(maxpdf*maxps,6,6)
      real*8 mm2pdfpdfiiqq_0(maxpdf*maxps,-4:4,-4:4,6,6)
C      real*8 mm2pdfpdfiiiiqq_0(maxpdf*maxps,-4:4,-4:4,-4:4,-4:4,6,6)

      real*8 mm2pdfpdfql_0(maxpdf*maxps,6,6)
      real*8 mm2pdfpdfiiql_0(maxpdf*maxps,-4:4,-4:4,6,6)
C      real*8 mm2pdfpdfiiiiql_0(maxpdf*maxps,-4:4,-4:4,-4:4,-4:4,6,6)
      real*8 mm2pdfpdflq_0(maxpdf*maxps,6,6)
      real*8 mm2pdfpdfiilq_0(maxpdf*maxps,-4:4,-4:4,6,6)
C      real*8 mm2pdfpdfiiiilq_0(maxpdf*maxps,-4:4,-4:4,-4:4,-4:4,6,6)


      real*8 mm2pdfpdfq2_0(maxpdf*maxps,6)
      real*8 mm2pdfpdfiiq2_0(maxpdf*maxps,-4:4,-4:4,6)
      real*8 mm2pdfpdftt_0(maxpdf*maxps,6,6)
      real*8 mm2pdfpdfiitt_0(maxpdf*maxps,-4:4,-4:4,6,6)
C      real*8 mm2pdfpdfiiiitt_0(maxpdf*maxps,-4:4,-4:4,-4:4,-4:4,6,6)
      real*8 mm2pdfpdft2_0(maxpdf*maxps,6)
      real*8 mm2pdfpdfiit2_0(maxpdf*maxps,-4:4,-4:4,6)
      common/mpdfcommon/mm2pdfpdf_0,mm2pdfpdfii_0,
     &    mm2pdfpdf_vw,mm2pdfpdfii_vw,
     &    mm2pdfpdf_vs,mm2pdfpdfii_vs,
     &    mm2pdfpdfqq_0,mm2pdfpdfiiqq_0,
C     &    mm2pdfpdfiiiiqq_0,
     &    mm2pdfpdftt_0,mm2pdfpdfiitt_0,
C     &    mm2pdfpdfiiiitt_0,
     &    mm2pdfpdfq2_0,mm2pdfpdfiiq2_0,
     &    mm2pdfpdft2_0,mm2pdfpdfiit2_0,
     &    mpdf1,mpdf2,mpdf_phot1,mpdf_phot2,
     &    alphasratio,pdfmemberfrom,pdfmemberto,
     &    pdfmembercentral

      real*8 mweight_0(maxpdf),mweightii_0(maxpdf,-4:4,-4:4)
      real*8 mweight(maxpdf,maxcon,maxps)
      real*8 mweightii(maxpdf,maxcon,-4:4,-4:4,maxps)
      common/mpdfweightcommon/mweight_0,mweightii_0,mweight,mweightii

      real*8 maverage(maxpdf),mweighttot(maxpdf)
      real*8 msigma(maxpdf),msigmaa(maxpdf),msigmatot(maxpdf) 
      real*8 mweightgen(maxpdf,maxcon)
      real*8 mavgen(maxpdf,0:maxg,maxcon),msigen(maxpdf,0:maxg,maxcon)
      real*8 mavgencha(maxpdf,0:maxg,maxcon,maxch)
      real*8 msigencha(maxpdf,0:maxg,maxcon,maxch)
      real*8 mavborn(maxpdf),msiborn(maxpdf)
      common/mpdfresultcommon/maverage,mweighttot,msigma,msigmaa,
     &                        msigmatot,mweightgen,mavgen,msigen,
     &                        mavgencha,msigencha,mavborn,msiborn
