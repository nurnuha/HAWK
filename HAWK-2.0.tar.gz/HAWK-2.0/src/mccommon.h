* -*-Fortran-*-

***********************************************************************
*     file mccommon.h                                                 *
*     common blocks for Monte Carlo                                   *
*---------------------------------------------------------------------*
*     30.01.06  Ansgar Denner     last changed  15.11.12              *
***********************************************************************

*  Input to generator.F:
*
*  initgenerator: lenergy,smin,lhepnum,generator,lnext,
*                 lsmodel,lsincludecuts,lssub,flag
*  mcgenerator: mcmass,mcwidth,power
*  mcoutput:    mout,numout,maxout,noutgen
*  mcadaptopt:  wi
*  mccuts:      ecutp,ecutl,ecutq,scutqq,ccutpb,ccutpl,ccutpq,
*               ccutll,ccutqq,ccutlq,ccutlb,ccutqb,ecut,scut,ccut,xmin
*
*  Output of generator.F:
*
*  mcgenerator: nchannel
*  mcadaptopt:  alphaopt       (move calculation of gsum to density!?)
*               betaopt     -> choice of channel 





* Common Blocks linked to "generator.F"

c mcparticle     only in generator
      integer mcfamily(-maxv:maxv,6),light(-maxv:maxv),naux,nmap
      character*4 pname(-maxv:maxv),gname(-maxv:maxv)
      common/mcparticle/pname,gname,mcfamily,light,naux,nmap

c mcgenerator    in generator and montecarlo 
      real*8 mcmass(0:maxv),mcwidth(0:maxv),power(0:maxv)
      integer nchannel(0:maxg)
      logical lcmsgen,lprintweightmax
      integer lnoutgen
      common/mcgenerator/mcmass,mcwidth,power,nchannel,lcmsgen,
     &    lnoutgen,lprintweightmax

c mckinematics    only in generator and mcmodel(init_subprocesses)
      real*8 massext2(maxe,0:maxg)
      integer allbinary(0:maxe,0:maxg),nexternal(0:maxg)
      common/mckinematics/massext2,allbinary,nexternal

c mcinv           only in generator
      real*8 powerinv(maxe,maxch,0:maxg),mcutinv(0:2**maxe,0:maxg)
      integer ininv(maxe,maxch,0:maxg),idhepinv(maxv,maxch,0:maxg)
      integer idhepfirst(maxch,0:maxg),ninv(maxch,0:maxg)
      logical lmin(maxe,maxe,maxch,0:maxg),lmax(maxe,maxe,maxch,0:maxg)
      common/mcinv/powerinv,mcutinv,ininv,idhepinv,idhepfirst,ninv,
     *  lmin,lmax

c mcprocess       only in generator
      real*8 powerprocess(maxe,maxch,0:maxg),tcutprocess(2**maxe,0:maxg)
      integer in1process(maxe,maxch,0:maxg),
     &    in2process(maxe,maxch,0:maxg)
      integer out1process(maxe,maxch,0:maxg),
     &    out2process(maxe,maxch,0:maxg)
      integer inprocess(maxe,maxch,0:maxg),
     &    virtprocess(maxe,maxch,0:maxg)
      integer idhepprocess(maxe,maxch,0:maxg),nprocess(maxch,0:maxg)
      common/mcprocess/powerprocess,tcutprocess,in1process,
     *  in2process,out1process,out2process,inprocess,virtprocess,
     *  idhepprocess,nprocess

c mcdecay         only in generator
      integer indecay(maxe,maxch,0:maxg),out1decay(maxe,maxch,0:maxg)
      integer out2decay(maxe,maxch,0:maxg),ndecay(maxch,0:maxg)
      common/mcdecay/indecay,out1decay,out2decay,ndecay

c mcdensity       only in generator
      integer nsinv(maxiv,0:maxg),chinv(maxiv,0:maxg),maxinv(0:maxg)
      integer ntprocess(maxpr,0:maxg),chprocess(maxpr,0:maxg)
      integer maxprocess(0:maxg),nsdecay(maxdc,0:maxg),
     &    chdecay(maxdc,0:maxg)
      integer maxdecay(0:maxg),numinv(maxiv,maxch,0:maxg)
      integer numprocess(maxpr,maxch,0:maxg)
      integer numdecay(maxch,maxch,0:maxg)
      common/mcdensity/nsinv,chinv,maxinv,ntprocess,chprocess,
     *  maxprocess,nsdecay,chdecay,maxdecay,numinv,numprocess,numdecay

c mcoutput        in generator and montecarlo
      integer nout,numout,maxout,noutgen,nsteps,lnoutmc
      common/mcoutput/nout,numout,maxout,noutgen,nsteps,lnoutmc

c mcmap           only in generator + montecarlo
c powerexmap maps 1/(1-x)^powermap  in transformations of phasespaces
c powerprop  maps (1/p^2)^powermap  in massless propagators
      real*8 powerprop,powerexmap
      integer emmap(maxch,0:maxg),spmap(maxch,0:maxg),
     &    comap(maxch,0:maxg)
      logical lmap(0:maxe,0:maxe,0:maxe,0:maxg)
      common/mcmap/powerprop,powerexmap,emmap,spmap,comap,lmap

c mctechparam     only in generator
      real*8 techparam(4)
      common/mctechparam/techparam

c mcadaptopt      in montecarlo and generator
      real*8 alphaopt(maxch,maxo,0:maxg),betaopt(0:maxch,0:maxg)
      real*8 wi(maxch,0:maxg),alphamin
      integer nopt(0:maxo,0:maxg),opt(0:maxg)
      common/mcadaptopt/alphaopt,betaopt,wi,alphamin,nopt,opt

c mccuts          in public, montecarlo, and generator
      real*8 ptcuth,ptcutp,ptcutj,ptcuts,ptcutl,ptcutm,ptcutv
      real*8 ptcutj1,ptcutj2,ptcutvis
      real*8 ptmaxvis,ptmaxl,ptmaxj1,ptmaxj2,ptmaxj3
      real*8 ecuth,ecutp,ecutj,ecuts,ecutl
      real*8 ycuth,ycutp,ycutj,ycuts,ycutl,ycutj1,ycutj2
      real*8 yminj1,yminj2,yminj3,yminl
      real*8 ccuthb,ccutpb,ccutjb,ccutlb
      real*8 ccutjh,ccutjp,ccutjj,ccutjl,ccutll
      real*8 dycutjh,dycutjp,dycutjj,dycutjl,dycutll
      real*8 dRcutjh,dRcutjp,dRcutjj,dRcutjs,dRcutjl
      real*8 dRcutlh,dRcutlp,dRcutls,dRcutll
      real*8 mcutjh,mcutjp,mcutjj,mcutjl,mcutll
      real*8 mlcutjj,mucutjj,mlcutll,mucutll
      real*8 ecut(maxe,0:maxg),ptcut(maxe,0:maxg),ycut(maxe,0:maxg)
      real*8 scut(maxe,maxe,0:maxg),ccut(maxe,maxe,0:maxg)
      real*8 dRcut(maxe,maxe,0:maxg),dycut(maxe,maxe,0:maxg)
      real*8 dphicutj1h,dphicutj2h
      real*8 xmin(0:maxg),xminp
      logical lhemicut,lhiggsbjets
      common/mccuts/ ptcuth,ptcutp,ptcutj,ptcuts,ptcutl,ptcutm,ptcutv,
     &    ptcutj1,ptcutj2,ptcutvis,ptmaxvis,ptmaxl,
     &    ptmaxj1,ptmaxj2,ptmaxj3,
     &    ecuth,ecutp,ecutj,ecuts,ecutl,
     &    ycuth,ycutp,ycutj,ycuts,ycutl,ycutj1,ycutj2,
     &    yminj1,yminj2,yminj3,
     &    yminl,
     &    ccuthb,ccutpb,ccutjb,ccutlb,
     &    ccutjh,ccutjp,ccutjj,ccutjl,ccutll,
     &    mcutjh,mcutjp,mcutjl,mcutll,
     &    mlcutjj,mucutjj,mlcutll,mucutll,
     &    dycutjh,dycutjp,dycutjj,dycutjl,dycutll,
     &    dRcutjh,dRcutjp,dRcutjj,dRcutjs,dRcutjl,
     &    dRcutlh,dRcutlp,dRcutls,dRcutll,
     &    dphicutj1h,dphicutj2h,
     &    ecut,ptcut,ycut,
     &    scut,ccut,dRcut,dycut,
     &    xmin,xminp,lhemicut,lhiggsbjets


c mhcuts
      real*8 mlcuth,mucuth,slcuth,sucuth
      common/mhcuts/ mlcuth,mucuth,slcuth,sucuth


c mccutsgen          in montecarlo and generator
      real*8 ecutgen(maxe,0:maxg),mtotcutgen
      real*8 scutgen(maxe,maxe,0:maxg),ccutgen(maxe,maxe,0:maxg)
      common/mccutsgen/ ecutgen,scutgen,ccutgen,mtotcutgen


* Common Blocks linked to "montecarlo.F"

c mcinput    in public and montecarlo and initamps
c nevents      number of events
c freqgencon   frequency of calculation for generator and contribution
c               (nevents(generator,contribution)=freqgencon*nevents)
      real*8 energy
      integer nevents,freqgencon(0:maxg,maxcon),nextgen(0:maxg),
     &    ngenerator
      integer nextmax,nextme(0:maxg),nextsub(0:maxg)
      character*16 name(maxe,0:maxg)
      character*60 outputfile,outputfile2
      character*20 outputvar
      common/mcinput/energy,nevents,freqgencon,nextgen,nextme,nextsub,
     &    ngenerator,
     &    nextmax,name,outputfile,outputfile2,outputvar

c mcrs in public and montecarlo, initamps
      integer salp
      common/mcrs/salp

c mcoptions  in public and montecarlo, initamps
      integer smodel,sirtr,sew,sweak,sferm,sbos
      integer sppbar,shadin1,shadin2
      integer swidth,scp,swdiag,szdiag
      integer sqcd,sqcddiag,sqcdnondiag,sqcdgsplit,sqcdggfus
      integer sscha,stcha,sch2,schint,sbini,sbfin,shh2
      integer sreal,sexcl
      integer slightfermions,snf,ssoft,sborn(0:maxg)
      integer sgen(0:maxg),sgencon(0:maxg,maxcon),scon(maxcon)
      integer swborn(0:maxg),svirt(0:maxg),spbrems(0:maxg),sconv(0:maxg)
      integer sgbrems(0:maxg),spinc(0:maxg),sginc(0:maxg),ssli(0:maxg)
      integer soaisr(0:maxg),ssub(0:maxg),sendp(0:maxg),scuts(0:maxg)
      integer sincludecuts(0:maxg)
      integer seff(0:maxg)
      integer sfactqed,sfactqcd
      integer shtr,sonsproj,shbw,sgh
      integer shvv
      logical lonsborn,lonsqcd,lonsew
      common/mcoptions/smodel,sirtr,sew,sweak,sreal,sexcl,
     &    sppbar,shadin1,shadin2,
     &    sqcd,sqcddiag,sqcdnondiag,sqcdgsplit,sqcdggfus,sferm,sbos,
     &    sscha,stcha,sch2,schint,sbini,sbfin,shh2,
     &    slightfermions,snf,ssoft,sgen,sgencon,scon,
     &    sborn,swborn,svirt,spbrems,
     &    sgbrems,spinc,sginc,
     &    sconv,soaisr,ssub,ssli,sendp,scuts,sincludecuts,
     &    sfactqed,sfactqcd,seff
     &    ,swidth,scp,swdiag,szdiag
     &    ,shtr,sonsproj,shbw,sgh,
     &    shvv,
     &    lonsborn,lonsqcd,lonsew

c mcevent    only in montecarlo
c replaced by mcpdfevent
c      real*8 weight(maxps),pbeam(2,0:3),pevent(maxe,0:3,maxps)
c      real*8 weightborn,pborn(maxe,0:3)
c      integer nweight
c      common/mcevent/weight,pbeam,pevent,weightborn,pborn,nweight

c mcborn     in public and montecarlo
c replaced by mcmat2
c      real*8 born(0:maxe,maxps),virtual(maxps)
c      common/mcborn/born,virtual

c mcresult   only in montecarlo
c in integration,writeresult and initialization
c average,sigma        total average and variance
c av     ,si           average and variance of last set of events
c avborn,sibotn        total average and variance of Born
c avgen,sigen          average and variance for generator and contribution
c avgencha,sigencha    average and variance for generator,contribution
c                      and channel
c weighttotmax         maximal total weight
c weightmax            maximal weight per generator and contribution
c weightmaxcha         maximal weight per generator, contribution
c                      and channel
c nevt                 number of events
c nunw                 number of unweighted events
c nneg                 number of negative unweighted events
c nmaxtot              number of event with maximal total weight
c nmax                 number of event with maximal weight
C                      per generator,contribution 
c channelmax           channel with maximal weight per generator 
c                      and contribution
c ngencha              number of events per generator,contribution and
c                      channel
c rejcha               number of rejected events per generator,
c                      contribution and channel
c ngen                 number of events per generator,contribution 
c rejgen               number of events per generator,contribution 
c nmaxcha              number of event with maximal weight
c                      per generator,contribution and
c                      channel
c processname          name of process
      real*8 average,sigma,av,si,avborn,siborn,sigmaa
      real*8 avgen(0:maxg,maxcon),sigen(0:maxg,maxcon)
      real*8 avgencha(0:maxg,maxcon,maxch),sigencha(0:maxg,maxcon,maxch)
      real*8 weighttotmax,weightmax(0:maxg,maxcon),wmax
      real*8 weightmaxcha(0:maxg,maxcon,maxch)
      integer nevt,nunw,nneg,rejgen(0:maxg,maxcon),
     &    nevtgen(0:maxg,maxcon),nmaxtot,nmax(0:maxg,maxcon),
     &    channelmax(0:maxg,maxcon),nevtgencha(0:maxg,maxcon,maxch),
     &    rejcha(0:maxg,maxcon,maxch),nmaxcha(0:maxg,maxcon,maxch)
      character*70 processname(0:maxg)
      common/mcresult/average,sigma,sigmaa,
     &    av,si,avborn,siborn,avgen,sigen,
     *    avgencha,sigencha,
     &    weighttotmax,weightmax,wmax,weightmaxcha,
     &    nevt,nunw,nneg,nmaxtot,nmax,channelmax,nevtgencha,
     &    rejcha,nevtgen,rejgen,nmaxcha,
     &    processname

c mcrecomb   in public and montecarlo
      real*8 recparam(maxre,0:maxg)
      integer srecomb(0:maxg),recparticle(maxe,0:maxg)
      common/mcrecomb/recparam,srecomb,recparticle

c mcconv     in montecarlo and initamps
      real*8 gam,betae
      common/mcconv/gam,betae

c mcsub      only in montecarlo
      real*8 const(maxe,maxe),qedfactor(maxe,maxe,0:maxg)
      real*8 qcdfactor(maxe,maxe,0:maxg),factor(0:maxg),
     &    mass2(maxe,0:maxg)
      real*8 lambda2(0:maxg),powersplitf,powersplitp
      real*8 tcdeltae,tcdeltas,tcdeltac
      common/mcsub/const,qedfactor,qcdfactor,factor,mass2,lambda2,
     *  powersplitf,powersplitp,tcdeltae,tcdeltas,tcdeltac

c mcranopt   only in montecarlo
      real*8 beran(0:maxgr,maxr,0:maxg),
     &    alran(maxgr,maxr,0:maxg)
      real*8 alminran,wran(maxgr,maxr,0:maxg)
      integer noptran(0:maxg)
      common/mcranopt/beran,alran,alminran,wran,noptran

c mcmadgraph in public and montecarlo
c      integer madprop
c      character*70 madprocess(0:maxg),madprocesssub(0:maxg)
c      common/mcmadgraph/madprop,madprocess,madprocesssub

c mcpol      in public and montecarlo and initamps 
      real*8 pol(2)
      common/mcpol/pol

c !!! move part to mcextparticles
c mcparam    in public and montecarlo 
      real*8 mcel,mcalpha,mcalpha0,mcalphaz,mcalphas,mcalphasz,mcgf
      real*8 mccw,mclambda,mcm(maxv),mcw(maxv),mcgevtofb
      real*8 mgl,mue,ma0,tb,mgo1,mgo2,msusy
      real*8 msl(3),mse(3),msq(3),msu(3),msd(3),atau,at,ab
      character*16 hepname(-maxip:maxip)
      integer nvirt
      common/mcparam/mcel,mcalpha,mcalpha0,mcalphaz,mcalphas,mcalphasz,
     &    mcgf,mccw,mclambda,mcm,mcw,mcgevtofb,
     &    mgl,mue,ma0,tb,mgo1,mgo2,msusy,msl,mse,
     *    msq,msu,msd,atau,at,ab,hepname,nvirt

c mchisto    in public and montecarlo 
      integer nhisto,lhisto(0:maxh),shisto
      common/mchisto/nhisto,lhisto,shisto

c mcnonsmcoupl in public and initamps
      real*8 gaahsm
      integer sgaah
      common/mcnonsmcoupl/gaahsm,sgaah




c added common blocks

c mcprocessparticles  in montecarlo
      real*8 mccharge(maxe,0:maxg)
      common/mcprocessparticles/mccharge

c mcextparticles    in public and montecarlo and mcmodel
      logical partcont(maxip,-maxv:maxv)
      character*16 class(-maxip:maxip)
      integer hepnum(-maxip:maxip,0:maxg),family(-maxip:maxip),ncomp
      common/mcextparticles/hepnum,class,family,partcont,ncomp

c mcpartprocesses   in public and mcmodel
      integer prochepnum(maxe,maxpp,0:maxg),nproc(0:maxg)
      common/mcpartprocesses/prochepnum,nproc

c mcpartons         in public and montecarl
      integer nparton
      real*8 m2parton(-maxpart:maxpart)
      common/mcpartons/m2parton,nparton

c mcmat2            in public and montecarlo
c for communication between crosssection and integrand
      real*8 m2pdfpdf_0(maxps),m2pdfpdfii_0(maxps,-5:5,-5:5)
      real*8 m2pdfpdf_vw(maxps),m2pdfpdfii_vw(maxps,-4:4,-4:4)
      real*8 m2pdfpdf_vs(maxps),m2pdfpdfii_vs(maxps,-4:4,-4:4)
      real*8 m2pdfpdfqq_0(maxps,6,6),m2pdfpdfiiqq_0(maxps,-4:4,-4:4,6,6)
      real*8 m2pdfpdfiiiiqq_0(maxps,-4:4,-4:4,-4:4,-4:4,6,6)
      real*8 m2pdfpdfq2_0(maxps,6),m2pdfpdfiiq2_0(maxps,-4:4,-4:4,6)
      real*8 m2pdfpdftt_0(maxps,6,6),m2pdfpdfiitt_0(maxps,-4:4,-4:4,6,6)
      real*8 m2pdfpdfiiiitt_0(maxps,-4:4,-4:4,-4:4,-4:4,6,6)
      real*8 m2pdfpdft2_0(maxps,6),m2pdfpdfiit2_0(maxps,-4:4,-4:4,6)

      real*8 m2pdfpdflq_0(maxps,6,6),m2pdfpdfiilq_0(maxps,-4:4,-4:4,6,6)
      real*8 m2pdfpdfiiiilq_0(maxps,-4:4,-4:4,-4:4,-4:4,6,6)
      real*8 m2pdfpdfql_0(maxps,6,6),m2pdfpdfiiql_0(maxps,-4:4,-4:4,6,6)
      real*8 m2pdfpdfiiiiql_0(maxps,-4:4,-4:4,-4:4,-4:4,6,6)

      logical lgencon(0:maxg,maxcon),lwborn(0:maxg)
      common/mcmat2/m2pdfpdf_0,m2pdfpdfii_0,
     &    m2pdfpdf_vw,m2pdfpdfii_vw,
     &    m2pdfpdf_vs,m2pdfpdfii_vs,
     &    m2pdfpdfqq_0,m2pdfpdfiiqq_0,m2pdfpdfiiiiqq_0,
     &    m2pdfpdftt_0,m2pdfpdfiitt_0,m2pdfpdfiiiitt_0,
     &    m2pdfpdfq2_0,m2pdfpdfiiq2_0,
     &    m2pdfpdft2_0,m2pdfpdfiit2_0,
     &    m2pdfpdflq_0,m2pdfpdfiilq_0,m2pdfpdfiiiilq_0,
     &    m2pdfpdfql_0,m2pdfpdfiiql_0,m2pdfpdfiiiiql_0,
     &    lgencon,lwborn

c mcpdfevent    only in montecarlo
c for communication between integrand and integration
c also in initialization (pbeam,pevent in settings) and 
c         writeresult (pbeam,pevent,weight in settings)
      real*8 weight_0,weightii_0(-4:4,-4:4)
      real*8 weight(maxcon,maxps),weightii(maxcon,-4:4,-4:4,maxps)
      real*8 pbeam(2,0:3),pevent(maxe,0:3,maxps),pborn(maxe,0:3)
      integer nweight,ncontr(0:maxg),nphsp(0:maxg)
      integer rejectedcon(maxcon,maxps),rejected(maxcon),rejected_0
      common/mcpdfevent/
     &    weight,weightii,
     &    pbeam,pevent, 			
     &    weight_0,weightii_0,pborn,
     &    nweight,ncontr,nphsp,
     &    rejectedcon,rejected,rejected_0

c>sk #include "sktest/mccommon/testweight_0.F"

c mcpdfresult   only in montecarlo
c for communication between integration and writeresult
      real*8 averageii(-4:4,-4:4),sigmaii(-4:4,-4:4)
      real*8 avbornii(-4:4,-4:4),sibornii(-4:4,-4:4)
      real*8 avgenii(0:maxg,maxcon,-4:4,-4:4),
     &    sigenii(0:maxg,maxcon,-4:4,-4:4)
      integer mccutsubevt((-2)*maxe:maxcut,0:maxg,maxcon,maxps)
      integer mccutevt((-2)*maxe:maxcut,0:maxg,maxcon)
      integer mccutevt_0((-2)*maxe:maxcut)

      common/mcpdfresult/averageii,sigmaii,avbornii,sibornii,
     &    avgenii,sigenii,mccutsubevt,mccutevt,mccutevt_0

c mcpdf         in public and montecarlo
      real*8 pdf1(-6:6),pdf2(-6:6),pdf_phot1,pdf_phot2
      integer spdf,pdfmap
      common/mcpdf/pdf1,pdf2,pdf_phot1,pdf_phot2,spdf,pdfmap

c mcpdfset
      character*196 pdfpath
      character*32  pdfname
      integer       pdfmember
      common/mcpdfset/pdfpath,pdfname,pdfmember

c mctest
      real*8 wconv,gcha(maxch,maxps),gsumm(maxps)
      integer cogen,cocha
      common/mctest/ wconv,gcha,gsumm,cogen,cocha

c mcslicing
      real*8 mcslideltac,mcslideltas,omxmaxf,omxmaxp
      common/mcslicing/mcslideltac,mcslideltas,omxmaxf,omxmaxp
      
c mcefffact
      real*8 mceffcut,mcollreg2
      common/mcslicing/mceffcut,mcollreg2      
      

c mccounters
      integer mcexitevt(0:maxexit,0:maxg)
      common/mccounters/mcexitevt

c mcktparameter
cad      real*8 ktd,partetacut
cad      common/mcktparameter/ktd,partetacut
      real*8 ktd,partetacut,dgammaparameter
      integer ktpower, sbarelep, colllep
      common/mcktparameter/ktd,partetacut,dgammaparameter,
     &     ktpower,sbarelep,colllep


c mchbr
      real*8 hbr
      common/mchbr/hbr

c xmax
      real*8 xpmax,xpmin,x1max,x1min,x2max,x2min,x3max,x3min
      common/xmax/ xpmax,xpmin,x1max,x1min,x2max,x2min,x3max,x3min

c qcdrenscale
      real*8 qcdrenscale,qcdrenscale2,qcdrenscalefac
      common /qcdrenscale/ qcdrenscale,qcdrenscale2,qcdrenscalefac

c qedfacscale
      real*8 qedfacscale,qedfacscale2,qedfacscalefac
      common /qedfacscale/ qedfacscale,qedfacscale2,qedfacscalefac

c qcdfacscale
      real*8 qcdfacscale,qcdfacscale2,qcdfacscalefac
      common /qcdfacscale/ qcdfacscale,qcdfacscale2,qcdfacscalefac

c mcprintmomenta    only in montecarlo
c contains generated momenta for printing
      real*8 pprint(maxe,0:3),x1print,x2print,xprint,omxprint
      common/mcprintmomenta/pprint,x1print,x2print,xprint,omxprint


c mcprocess
      character*5 initialstate
      character*12 finalstate
      common/mcprocess/initialstate,finalstate
