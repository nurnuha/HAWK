* -*-Fortran-*-

***********************************************************************
*     file input.h                                                    *
*     global parameters for input to ttbb Monte Carlo                 *
*---------------------------------------------------------------------*
*     20.06.07  Ansgar Denner     last changed  20.06.07              *
***********************************************************************

c inputpar
      real*8   alpha0in,alphazin,gfin,alphaszin
     &                 ,mzin,gzin,mwin,gwin,mhin,ghin
     &                 ,mein,mmuin,mtauin
     &                 ,mdin,msin,mbin
     &                 ,muin,mcin,mtin
     &                 ,sinthetacin,vin(3,3)
     &                 ,gevtofbin
     &                 ,lambdain,mudim2in
     &                 ,alphain,alphasin
      common /inputpar/ alpha0in,alphazin,gfin,alphaszin
     &                 ,mzin,gzin,mwin,gwin,mhin,ghin
     &                 ,mein,mmuin,mtauin
     &                 ,mdin,msin,mbin
     &                 ,muin,mcin,mtin
     &                 ,sinthetacin,vin
     &                 ,gevtofbin
     &                 ,lambdain,mudim2in
     &                 ,alphain,alphasin


