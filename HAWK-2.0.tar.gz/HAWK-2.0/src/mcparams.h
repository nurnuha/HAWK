* -*-Fortran-*-

***********************************************************************
*     file mcparams.h                                                 *
*     global parameters and variables for Monte Carlo                 *
*---------------------------------------------------------------------*
*     30.01.06  Ansgar Denner     last changed  08.12.06              *
***********************************************************************

        integer vcomp

* generators
	integer gen,ngen,maxg
* contributions per generator
        integer icon,maxcon
        external particles of process
        integer ext,ext1,ext2,maxe,maxf
* particles in the Monte Carlo model
        integer mcpart,mcpart1,mcpart2,mcpart3,mcpart4,maxv
* channels
        integer cha,ncha,maxch
* invariants
        integer maxiv
* t-channel processes
        integer maxpr
* decays
        integer maxdc
* events
        integer evt
* random numbers
        integer rnr,maxrnr
* optimization steps
        integer maxo
* histograms
        integer ihisto,maxh
* bins
        integer ibin,maxb
* recombination cuts
        integer maxre
* phase spaces
        integer iphsp,maxps
* input particles
        integer ipart,maxip
* grid partitions
        integer igrp,maxgr
* grid variables
        integer igrv,maxr

* partonic processes
        integer proc,maxpp

* partons
        integer iparton,parton1,parton2,parton3,parton4,maxpart

* exits
         integer iexit,maxexit
* cuts
        integer icut,maxcut

* parameters
        real*8 pi,pi2

* Parameters for the Process Definition:

* Number of partonic subprocesses
c      parameter(nproc = 20)
* Maximal number of particles for all considered processes
c      parameter(np = 5)

* Parameters for the MC Integration:

* maximal number of generators - 1
      parameter(maxg = 8)
* maximal number of contributions per generator
c>sk      parameter(maxcon = 9)
      parameter(maxcon = 11)
c>sk #include "sktest/mcparam/testweight_1.F"
* maximal number of external particles
      parameter(maxe = 7)
* maximal number of final-state particles
      parameter(maxf = 5)
* maximal number of particles in the considered model
      parameter(maxv = 200)
* maximal number of channels
      parameter(maxch = 105)
* maximal number of invariants
      parameter(maxiv = 101)
* maximal number of decays
      parameter(maxdc = 46)
* maximal number of t-channel processes
      parameter(maxpr = 134)
* maximal number of optimization steps
      parameter(maxo = 20)
* maximal number of histograms
      parameter(maxh = 50)
* maximal bins in histogram
      parameter(maxb=102)

* Maximal number of exits
      parameter(maxexit = 50)
* Maximal number of cuts
      parameter(maxcut = 54)
* Maximal number of recombination parameters
      parameter (maxre=4)
* Maximal number of phase spaces
      parameter (maxps=13)
* Maximal number of input particles
      parameter (maxip=130)

* Maximal number of grid partitions
      parameter (maxgr=500)

* Maximal variables for grid
      parameter (maxr=2)

* Maximal number of partonic processes
      parameter (maxpp=500)

* Maximal number of partons
      parameter (maxpart=10)

* Pi
      parameter (pi=3.141592653589793238462643383279502884197d0)
      parameter (pi2=9.869604401089358618834490999876151135314d0)
