TGraphErrors*
MakeGraph(const char* name, const char* title, Color_t col)
{
  TGraphError* g = new TGraphError;
  g->SetName(name);
  g->SetTitle(title);
  g->SetLineColor(col);
  g->SetFillColor(col);
  g->SetMarkerColor(col);
  g->SetFillStyle(3001);
  g->SetMarkerStyle(20);
  g->SetLineStyle(1);
  g->SetLineWidth(1);
  return g;
}
    
void
twograph()
{
  std::ifstream in("mZH05.txt"); 

  TGraph* ge = 0;
  
  Int_t cnt = 0;
  do {
    std::string l;
    std::getline(in, l);
    if (in.bad()) break;

    if (l[0] == '#') continue;

    std::stringstream parse(l);
    Double_t x;
    parse >> x;

    //   next.Reset();
    while ((ge = static_cast<TGraphError*>(next()))) {
      Double_t y, e;
      parse >> y >> e;
      ge->SetPoint(cnt, x, y);
    }
    cnt++;
  } while (!in.eof());

  TCanvas* c = new TCanvas("c", "C");
  mg->Draw("ap");

  c->BuildLegend(.2, .6, .5, .85);
  
}
