void
tree_xsec05()
{
  TCanvas *c = new TCanvas;

  TTree* lo = new TTree("lo", "X-section");
  TTree* qcd = new TTree("qcd", "X-section");
  TTree* ewk = new TTree("ewk", "X-section");
  TTree* all = new TTree("all", "X-section");

  lo->ReadFile("etaZH05.txt",
	      "etaZH/D:"
              "aXsec:eXsec");
  qcd->ReadFile("etaZH06.txt", 
              "etaZH/D:"
    	      "aXsec:eXsec");
  ewk->ReadFile("etaZH07.txt", 
              "etaZH/D:"
    	      "aXsec:eXsec");
  all->ReadFile("etaZH08.txt", 
              "etaZH/D:"
    	      "aXsec:eXsec");
  /*  	     
  lo->SetMarkerColor(kBlue+2); // LO only
  lo->SetMarkerStyle(2);
  qcd->SetMarkerColor(kRed+2); // NLOQCD only
  qcd->SetMarkerStyle(2);
  ewk->SetMarkerColor(kGreen+2); // NLOEWK only
  ewk->SetMarkerStyle(2);
  all->SetMarkerColor(kBlack); // Both
  all->SetMarkerStyle(2);
*/
  lo->SetMarkerColor(4); // LO only
  lo->SetMarkerStyle(2);
  qcd->SetMarkerColor(2); // NLOQCD only
  qcd->SetMarkerStyle(2);
  ewk->SetMarkerColor(3); // NLOEWK only
  ewk->SetMarkerStyle(2);
  all->SetMarkerColor(kBlack); // Both
  all->SetMarkerStyle(2);
  //  t->Draw("aXsec:massZH", "", "*");
  lo->Draw("aXsec:etaZH");
  qcd->Draw("aXsec:etaZH", "","Same");
  ewk->Draw("aXsec:etaZH", "","Same");
  all->Draw("aXsec:etaZH", "","Same");

 // Draw the Legend
    TLegend leg(.65,.75,.89,.88,"Graph");
    leg.SetFillColor(0);
    leg.AddEntry(lo,"LO");
    leg.AddEntry(qcd,"LO + NLO_QCD");
    leg.AddEntry(ewk,"LO + NLO_EWK");
    leg.AddEntry(all,"LO + NLOQCD + NLOEWK");

    leg.DrawClone("Same");
  
  c->SaveAs("etaZH.png");
}
//bins = getBinsFromTGraph(TGraph)
