//Reads the points from file, get the point x,y, calculate relative diff and lastly plot relative diff vs x03.

void Err05(){
 auto c=new TCanvas();
 c->SetGrid();

//Read the first file    
   TGraphErrors graph05("./pth05.txt","%lg %lg %lg");
   Int_t n = graph05.GetN();
   Double_t *x05 = graph05.GetX();
   Double_t *y05 = graph05.GetY();

//Read the second file
   TGraphErrors graph06("./pth06.txt","%lg %lg %lg");
   Double_t *y06 = graph06.GetY();
   
//Calculate the relative difference
   Double_t diff[101], rel_err[101];

    for (Int_t i=1; i<n; i++) {
      diff[i] = y05[i]-y06[i];
     rel_err[i] = diff[i]/y06[i];
     // cout<<"[i] "<<i<< "value_diff= "<<diff[i]<<endl;
     // printf("relative_err[%d] =  %g \n",i,rel_err);
     // printf("value_y03[%d]=%g \t diff[%d]=%g \t rel_err[%d]=%g\n",i,y03,i,diff,i,rel_err);
}
    TGraph *gr = new TGraph(n,x05,rel_err);
    //  Double_t fMinimum;
    // Double_t fMaximum;

    //    gr->SetMinimum(-0.15);
    //    gr->SetMaximum(-0.03);
    gr->SetTitle("Relative Difference vs pth");
    gr->GetXaxis()->SetTitle("pth");
    gr->GetYaxis()->SetTitle("Relative Difference");
    gr->SetMarkerStyle(20);
    gr->SetLineColor(kRed);
    gr->SetMarkerColor(kRed);
    gr->Draw("APL");

    c->SaveAs("pth_err.png");
}


