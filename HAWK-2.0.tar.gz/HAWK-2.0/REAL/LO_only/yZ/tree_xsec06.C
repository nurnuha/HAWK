void tree_xsec06() {

  // LO / NLO
  // Make sure uncertainty in histogram bins is calculated correctly
  TH1::SetDefaultSumw2(kTRUE);
  string ploTitle = "Plot of rapZ";
  const Int_t nBin = 100;

  TGraphErrors* g1 = new TGraphErrors();
  g1->SetName("g1");
  g1->SetMarkerColor(kRed + 1);
  g1->SetMarkerStyle(2);
  g1->SetMarkerSize(1);
  g1->SetLineColor(kRed);
  g1->SetLineWidth(2);

  std::ifstream in1("yZ05.txt"); 

  Int_t cnt = 0;
  do {
    std::string l1;
    std::getline(in1, l1);
    if (in1.bad()) break;

    if (l1[0] == '#') continue;

    std::stringstream parse(l1);

    Double_t x05, y05, e05;
    parse >> x05 >> y05 >> e05;
    g1->SetPoint(cnt, x05, y05);
    g1->SetPointError(cnt, 0., e05);

    cnt++;
    } while (!in1.eof());
  // g1->Draw("ap");
  
  // This is the frame histogram
  TH1F *frame_hist = new TH1F("", ploTitle.c_str(), nBin, -6., 6.);
  //frame_hist->SetEntries(0);
  frame_hist->SetLineWidth(0);
  frame_hist->GetYaxis()->SetTitle("Cross section");
  frame_hist->GetYaxis()->SetTitleSize(23);
  frame_hist->GetYaxis()->SetTitleFont(43);
  frame_hist->GetYaxis()->SetTitleOffset(1.25);
  frame_hist->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  frame_hist->GetYaxis()->SetLabelSize(21);
  frame_hist->SetAxisRange(0.01, 5.0, "y"); // Range of y axis in graph
  
// Declare first histogram
  TH1D *h1 = new TH1D("","",nBin,-6.,6.);
  h1->SetMarkerColor(kRed + 1);
  h1->SetLineColor(kRed);
  h1->SetLineWidth(2);
  h1->GetYaxis()->SetTitle("Cross Section");
  h1->GetYaxis()->SetTitleSize(23);
  h1->GetYaxis()->SetTitleFont(43);
  h1->GetYaxis()->SetTitleOffset(1.25);
  h1->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  h1->GetYaxis()->SetLabelSize(21);
  h1->SetAxisRange(0.01, 5.0, "y"); // Range of y axis in graph

  Double_t x105, y105, e105;
  Float_t xbin[nBin + 1];
  Float_t valuey[nBin + 1];
  for (Int_t i = 0; i < nBin; i++) { 

   valuey[i] = 1.;
   xbin[i] = -6. + ((Float_t) i / (Float_t) nBin * 6.);
   g1->GetPoint(i, x105, y105);
   g1->GetErrorY(e105);
   h1->SetBinContent(i+1, y105);
   h1->SetBinError(i+1, e105);
 }

   xbin[nBin] = 6.;

  //----------------------------Second Graph-----------------------------------//

 TGraphErrors* g2 = new TGraphErrors();
  g2->SetName("g2");
  g2->SetMarkerColor(kBlue + 1);
  g2->SetMarkerStyle(2);
  g2->SetMarkerSize(1);
  g2->SetLineColor(kBlue);
  g2->SetLineWidth(2);

 std::ifstream in2("yZ08.txt");

  Int_t cnt = 0;
  do {
    std::string l2;
    std::getline(in2, l2);
    if (in2.bad()) break;

    if (l2[0] == '#') continue;

    std::stringstream parse(l2);

    Double_t x08, y08, e08;
    parse >> x08 >> y08 >> e08;
    g2->SetPoint(cnt, x08, y08);
    g2->SetPointError(cnt, 0., e08);

    cnt++;
    } while (!in2.eof());
  // g2->Draw("psame");

  valuey[nBin] = 1.;
  TGraph *liner = new TGraph(nBin + 1, xbin, valuey);
  liner->SetLineColor(kYellow + 1);
  liner->SetLineWidth(2);

// Declare second histograms
  TH1D *h2 = new TH1D("h2","",nBin,-6.,6.);
  h2->SetMarkerColor(kBlue + 1);
  h2->SetLineColor(kBlue);
  h2->SetLineWidth(2);

  Double_t x108, y108, e108;
  for (Int_t ii = 0; ii < nBin; ii++) { 

   g2->GetPoint(ii, x108, y108);
   g2->GetErrorY(e108);
   h2->SetBinContent(ii+1, y108);
   h2->SetBinError(ii+1, e108);
 }

  TH1D *ratio_plot = new TH1D("", "", nBin, -6., 6.);
  ratio_plot->Divide(h1, h2, 1., 1., "B");
  ratio_plot->SetMarkerStyle(2);
  ratio_plot->SetMarkerColor(kBlack);
  ratio_plot->SetLineColor(kBlack);
  ratio_plot->SetTitle("");
  ratio_plot->GetYaxis()->SetTitle("Ratio (LO/NLO)");
  ratio_plot->GetYaxis()->SetNdivisions(505);
  ratio_plot->GetYaxis()->SetTitleSize(23);
  ratio_plot->GetYaxis()->SetTitleFont(43);
  ratio_plot->GetYaxis()->SetTitleOffset(1.25);
  ratio_plot->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  ratio_plot->GetYaxis()->SetLabelSize(21);
  ratio_plot->SetAxisRange(0.5, 1.5, "y");

  ratio_plot->GetXaxis()->SetTitle("rapZ");
  ratio_plot->GetXaxis()->SetTitleSize(23);
  ratio_plot->GetXaxis()->SetTitleFont(43);
  ratio_plot->GetXaxis()->SetTitleOffset(2.9);
  ratio_plot->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  ratio_plot->GetXaxis()->SetLabelSize(21);

  TCanvas *c1 = new TCanvas("c1", "Graph with error bars", 200, 10, 1000, 1000);
  gStyle->SetOptStat(0);

  // Upper plot will be in pad1
  TPad *pad1 = new TPad("pad1", "pad1", 0., 0.29, 1., 1.);
  pad1->SetBottomMargin(0); // Upper and lower plot are joined
  pad1->SetGrid();
  pad1->Draw();             // Draw the upper pad: pad1
  pad1->cd();               // pad1 becomes the current pad

  g1->SetHistogram(frame_hist);
  g2->SetHistogram(frame_hist);
  frame_hist->Draw("func");

  g1->Draw("p");
  g2->Draw("psame");
  //   h2->Draw();
  //  h1->Draw("same");

  TLegend *leg = new TLegend(.75, .05, .90, .19);
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->SetTextFont(42);
  leg->SetTextSize(0.03);

  leg->AddEntry(h1, "LO", "lp");
  leg->AddEntry(h2, "Full_NLO", "lp");
  leg->Draw();

  // lower plot will be in pad
  c1->cd();          // Go back to the main canvas before defining pad2
  TPad *pad2 = new TPad("pad2", "pad2", 0., 0., 1., 0.29);
  pad2->SetTopMargin(0);
  pad2->SetBottomMargin(0.2);
  pad2->SetGrid();
  pad2->Draw();
  pad2->cd();       // pad2 becomes the current pad);

  ratio_plot->Draw("p");
  liner->Draw("lsame");
  ratio_plot->Draw("psame");
  
  c1->cd();
  c1->SaveAs("/home/nuha/Documents/HAWK-2.0/REAL/LO_only/yZ/yZ.pdf");
  c1->Close();
  
}
//bins = getBinsFromTGraph(TGraph)
