void
tree_xsec05()
{
  TCanvas *c = new TCanvas;

  TTree* lo = new TTree("lo", "X-section");
  TTree* qcd = new TTree("qcd", "X-section");
  TTree* ewk = new TTree("ewk", "X-section");
  TTree* all = new TTree("all", "X-section");

  qcd->ReadFile("yh06.txt", 
              "yh/D:"
    	      "aXsec:eXsec");
  lo->ReadFile("yh05.txt",
	      "yh/D:"
              "aXsec:eXsec");
  ewk->ReadFile("yh07.txt", 
              "yh/D:"
    	      "aXsec:eXsec");
  all->ReadFile("yh08.txt", 
              "yh/D:"
    	      "aXsec:eXsec");
  /*  	     
  lo->SetMarkerColor(kBlue+2); // LO only
  lo->SetMarkerStyle(2);
  qcd->SetMarkerColor(kRed+2); // NLOQCD only
  qcd->SetMarkerStyle(2);
  ewk->SetMarkerColor(kGreen+2); // NLOEWK only
  ewk->SetMarkerStyle(2);
  all->SetMarkerColor(kBlack); // Both
  all->SetMarkerStyle(2);
*/
  qcd->SetMarkerColor(2); // NLOQCD only
  qcd->SetMarkerStyle(3);
  lo->SetMarkerColor(4); // LO only
  lo->SetMarkerStyle(3);
  ewk->SetMarkerColor(3); // NLOEWK only
  ewk->SetMarkerStyle(3);
  all->SetMarkerColor(kBlack); // Both
  all->SetMarkerStyle(3);
  //  t->Draw("aXsec:massZH", "", "*");
  qcd->Draw("aXsec:yh");
  lo->Draw("aXsec:yh", "","Same");
  ewk->Draw("aXsec:yh", "","Same");
  all->Draw("aXsec:yh", "","Same");

 // Draw the Legend
    TLegend leg(.65,.75,.89,.88,"Graph");
    leg.SetFillColor(0);
    leg.AddEntry(lo,"LO");
    leg.AddEntry(qcd,"LO + NLO_QCD");
    leg.AddEntry(ewk,"LO + NLO_EWK");
    leg.AddEntry(all,"LO + NLOQCD + NLOEWK");

    leg.DrawClone("Same");
  
  c->SaveAs("yh.png");
}
//bins = getBinsFromTGraph(TGraph)
