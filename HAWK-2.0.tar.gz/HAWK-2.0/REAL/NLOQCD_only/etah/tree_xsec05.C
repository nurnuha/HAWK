void
tree_xsec05()
{
  TCanvas *c = new TCanvas;

  TTree* t = new TTree("T", "X-sections");
  TTree* f = new TTree("F", "X-section");

  t->ReadFile("etah05.txt",
	      "etah/D:"
              "aXsec:eXsec");
  f->ReadFile("etah06.txt", 
              "etah/D:"
    	      "aXsec:eXsec");
  	     
  t->SetMarkerColor(4); //4 is blue: with EW correction
  t->SetMarkerStyle(2);
  f->SetMarkerColor(2); //2 is red:without EW correction
  f->SetMarkerStyle(2);
  //  t->Draw("aXsec:massZH", "", "*");
  t->Draw("aXsec:etah");
  f->Draw("aXsec:etah", "","Same");

 // Draw the Legend
    TLegend leg(.6,.65,.85,.8,"Graph");
    leg.SetFillColor(0);
    leg.AddEntry(t,"With EW correction");
    leg.AddEntry(f,"Without EW correction");
    leg.DrawClone("Same");

  c->SaveAs("etah.png");
}
//bins = getBinsFromTGraph(TGraph)
